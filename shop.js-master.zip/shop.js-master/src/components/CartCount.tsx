import React from 'react'
import ReactDOM from 'react-dom'

export default ({
  count,
}) => {
  return (
    <div>{ count }</div>
  )
}
